export ALLOY_HOME=/usr/share/alloy
